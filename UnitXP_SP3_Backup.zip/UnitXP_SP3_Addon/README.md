# UnitXP_SP3_Addon
WoW Vanilla 1.12 Lua Addon for supporting [UnitXP SP3 mod](https://github.com/allfoxwy/UnitXP_SP3)
