# sentry - WoW 1.12 addOn 

Move the frame with **ctrl-drag**.
The addon alerts you of nearby enemies which it detects through the combat log or active scanning. Active scanning is done once per combat log event, every 30 seconds for active frames, and constantly for recently seen enemies as well as enemies manually configured with **/sentry toggle *name***. Scanning is done by automatic targeting, but only when it will not interfere with the game in any way (e.g., no active combo points). For the current target and mouseover information is updated continuously.

![Alt text](https://i.imgur.com/jiOaN9G.png)