# MessageBox
Stores and displays whisper conversation history

Open the UI with /messagebox, /mbox, or /mb


![WoWScrnShot_071625_143254 tga](https://github.com/user-attachments/assets/fbda07c4-af24-42c1-8fa7-b785175e5a21)
