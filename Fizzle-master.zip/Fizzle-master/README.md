Fizzle is an addon that will show you an items durability values above the item in your character frame.
It can show you either the raw values, or a percentage value.
Why Fizzle? Well, I suck at coming up with names is why.

Slash Commands
/fizzle or /fizz

percent - Toggle between raw and percentage display.
border - Toggles the quality colours on the border of items.
invert - Changes how the durability is shown. Eg. 0% = Max durability, 100% = No durability.
hidetext - Hides the durability text, incase you just want the item quality colouring.
showfull - Toggles showing durability when full. If enabled, durability text is always shown, if disabled, durability text is only shown if durability is less than 100%
inspect - Toggles the inspection module.

Fizzle was written by Phyber
