# RogueFocus
RogueFocus Classic WoW addon for 1.12.x

Compact Combo/Energy/Tick display

**/rfc** for options.
