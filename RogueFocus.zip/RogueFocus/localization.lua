ROGUEFOCUS			= "Rogue Focus Classic";
ROGUEFOCUS_WELCOME	= "Rogue Focus Classic: type /roguefocus or /rfc for options.";

ROGUEFOCUS_ENERGY	= "Energy Ticks";
ROGUEFOCUS_SCALE	= "Scale";
ROGUEFOCUS_LOW		= "Low";
ROGUEFOCUS_HIGH		= "High";
ROGUEFOCUS_COMBAT	= "Show in combat";
ROGUEFOCUS_STEALTH	= "Show in stealth";
ROGUEFOCUS_OTHER	= "Show in other cases";
ROGUEFOCUS_SOUND	= "Audible ticks";
ROGUEFOCUS_LOCK		= "Lock in place";
ROGUEFOCUS_MOVE		= "Tip: Uncheck Lock \nand drag to move."